-- Clips — MySQL schema
-- Run against a MySQL 8+ server:  mysql -u root -p < db/schema.sql
-- (or use `npm run db:setup` which executes this file for you).

CREATE DATABASE IF NOT EXISTS clips
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE clips;

-- Workspace members / clip authors.
CREATE TABLE IF NOT EXISTS users (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(120)    NOT NULL,
  email       VARCHAR(190)    NOT NULL,
  avatar_url  VARCHAR(500)    NULL,
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Recorded clips.
--   kind = 'video'   → screen recording      (Video Clips)
--         'voice'   → mic-only audio note    (Voice Clips)
--         'syncup'  → recorded team call      (SyncUps)
--         'meeting' → AI Notetaker recording  (AI Notetaker)
CREATE TABLE IF NOT EXISTS clips (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  slug            VARCHAR(24)     NOT NULL,        -- public share id (used in /clip/[slug])
  title           VARCHAR(255)    NOT NULL,
  kind            ENUM('video','voice','syncup','meeting') NOT NULL DEFAULT 'video',
  video_path      VARCHAR(500)    NOT NULL,        -- relative path under /public
  mime_type       VARCHAR(100)    NOT NULL DEFAULT 'video/webm',
  duration        INT UNSIGNED    NOT NULL DEFAULT 0,   -- seconds
  size_bytes      BIGINT UNSIGNED NOT NULL DEFAULT 0,
  resolution      VARCHAR(20)     NOT NULL DEFAULT '1080p',
  views           INT UNSIGNED    NOT NULL DEFAULT 0,
  -- AI Notetaker / SyncUp extras (nullable JSON; populated by a transcription step)
  summary         TEXT            NULL,            -- AI meeting summary
  participants    JSON            NULL,            -- ["Talha","Sara"]
  transcript      JSON            NULL,            -- [{ "t":0,"speaker":"Talha","text":"…" }]
  action_items    JSON            NULL,            -- [{ "who":"Omar","text":"…" }]
  transcript_text TEXT            NULL,            -- flattened transcript for search
  author_id       BIGINT UNSIGNED NULL,
  created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_clips_slug (slug),
  KEY idx_clips_created (created_at),
  KEY idx_clips_kind (kind),
  FULLTEXT KEY ft_clips_search (title, summary, transcript_text),
  CONSTRAINT fk_clips_author FOREIGN KEY (author_id)
    REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Threaded-ish comments left on a clip's share page.
CREATE TABLE IF NOT EXISTS comments (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  clip_id     BIGINT UNSIGNED NOT NULL,
  author_name VARCHAR(120)    NOT NULL DEFAULT 'Guest',
  body        TEXT            NOT NULL,
  ts_seconds  INT UNSIGNED    NULL,              -- optional timeline anchor
  created_at  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_comments_clip (clip_id),
  CONSTRAINT fk_comments_clip FOREIGN KEY (clip_id)
    REFERENCES clips (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- A default author so fresh installs have something to attribute clips to.
INSERT INTO users (name, email, avatar_url)
SELECT 'Talha Tahir', 'talha@clips.local', NULL
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'talha@clips.local');
