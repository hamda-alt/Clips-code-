import SyncUpCall from '@/components/SyncUpCall';

export const metadata = { title: 'SyncUp call · Clips' };

// A SyncUp call. In the product this is launched from a chat/DM with a teammate;
// the recording auto-saves to SyncUps (or AI Notetaker when the notetaker is on).
export default function CallPage() {
  return <SyncUpCall />;
}
