import AppShell from '@/components/AppShell';
import Welcome from '@/components/Welcome';
import ClipsBrowser from '@/components/ClipsBrowser';
import DbBanner from '@/components/DbBanner';
import EmptyKind from '@/components/EmptyKind';
import { listClips, searchClips } from '@/lib/clips';

export const dynamic = 'force-dynamic';

const KINDS = ['video', 'voice', 'syncup', 'meeting'];

export default async function DashboardPage({ searchParams }) {
  const kind = KINDS.includes(searchParams?.kind) ? searchParams.kind : undefined;
  const q = (searchParams?.q || '').trim();

  let clips = null;
  let dbDown = false;
  try {
    clips = q ? await searchClips(q) : await listClips({ kind });
  } catch (err) {
    console.error('[dashboard] db error:', err?.code || err?.message);
    dbDown = true;
  }

  // Sidebar badge count for Video Clips (best-effort).
  let counts = {};
  if (!dbDown) {
    try {
      const all = kind || q ? await listClips({}) : clips;
      counts = { video: all.filter((c) => c.kind === 'video').length };
    } catch {
      /* ignore */
    }
  }

  return (
    <AppShell counts={counts} activeKind={q ? undefined : kind}>
      {dbDown ? (
        <DbBanner />
      ) : q ? (
        <ClipsBrowser clips={clips} heading={`Results for “${q}”`} isSearch />
      ) : clips.length === 0 && !kind ? (
        <Welcome />
      ) : clips.length === 0 ? (
        <EmptyKind kind={kind} />
      ) : (
        <ClipsBrowser clips={clips} kind={kind} />
      )}
    </AppShell>
  );
}
