import Link from 'next/link';
import { notFound } from 'next/navigation';
import Sidebar from '@/components/Sidebar';
import VideoPlayer from '@/components/VideoPlayer';
import Comments from '@/components/Comments';
import ClipNotes from '@/components/ClipNotes';
import CopyLinkButton from '@/components/CopyLinkButton';
import { VideoIcon, MicIcon, SyncIcon, SparkIcon, DotsIcon, BackIcon } from '@/components/icons';
import { getClipBySlug, incrementViews } from '@/lib/clips';
import { timeAgo } from '@/lib/format';

export const dynamic = 'force-dynamic';

function KindIcon({ kind }) {
  const cls = 'shrink-0 text-brand';
  if (kind === 'voice') return <MicIcon width={16} height={16} className={cls} />;
  if (kind === 'syncup') return <SyncIcon width={16} height={16} className={cls} />;
  if (kind === 'meeting') return <SparkIcon width={16} height={16} className={cls} />;
  return <VideoIcon width={16} height={16} className={cls} />;
}

export async function generateMetadata({ params }) {
  try {
    const clip = await getClipBySlug(params.slug);
    return { title: clip ? `${clip.title} · Clips` : 'Clip · Clips' };
  } catch {
    return { title: 'Clip · Clips' };
  }
}

export default async function ClipPage({ params }) {
  let clip;
  try {
    clip = await getClipBySlug(params.slug);
  } catch (err) {
    throw new Error('Database unavailable');
  }
  if (!clip) notFound();

  // Fire-and-forget view count.
  incrementViews(params.slug).catch(() => {});

  return (
    <div className="flex h-screen overflow-hidden bg-ink-950">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Breadcrumb header */}
        <header className="flex h-14 shrink-0 items-center gap-3 border-b border-ink-700 bg-ink-950/80 px-4 backdrop-blur">
          <Link href="/" className="grid h-7 w-7 place-items-center rounded-md text-muted hover:bg-ink-850 hover:text-white md:hidden">
            <BackIcon width={18} height={18} />
          </Link>
          <Link href="/" className="hidden text-sm text-muted hover:text-white md:inline">
            Clips
          </Link>
          <span className="hidden text-faint md:inline">/</span>
          <span className="flex min-w-0 items-center gap-2 text-sm">
            <KindIcon kind={clip.kind} />
            <span className="truncate font-medium text-white/90">{clip.title}</span>
          </span>
          <span className="flex-1" />
          <CopyLinkButton slug={clip.slug} />
          <button className="grid h-8 w-8 place-items-center rounded-md text-muted hover:bg-ink-850 hover:text-white">
            <DotsIcon width={16} height={16} />
          </button>
        </header>

        <main className="flex-1 overflow-y-auto px-5 py-6 md:px-8">
          <div className="mx-auto max-w-4xl">
            <VideoPlayer src={clip.video_path} />

            <div className="mt-5 flex flex-wrap items-start justify-between gap-4">
              <div>
                <h1 className="text-xl font-semibold tracking-tight">{clip.title}</h1>
                <div className="mt-1.5 flex items-center gap-2 text-sm text-muted">
                  <span className="grid h-6 w-6 place-items-center rounded-full bg-gradient-to-br from-brand to-orange-500 text-[10px] font-bold text-white">
                    {(clip.author_name || 'Y').charAt(0).toUpperCase()}
                  </span>
                  <span className="font-medium text-white/80">{clip.author_name || 'You'}</span>
                  <span className="text-faint">· {timeAgo(clip.created_at)}</span>
                  <span className="text-faint">· {clip.views + 1} view{clip.views === 0 ? '' : 's'}</span>
                </div>
              </div>
            </div>

            <ClipNotes clip={clip} />

            <div className="mt-8 border-t border-ink-700 pt-6">
              <Comments slug={clip.slug} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
