import AppShell from '@/components/AppShell';
import Recorder from '@/components/Recorder';

export const metadata = { title: 'Record a clip · Clips' };

const KINDS = ['video', 'voice', 'syncup'];

export default function RecordPage({ searchParams }) {
  const initialKind = KINDS.includes(searchParams?.kind) ? searchParams.kind : 'video';
  return (
    <AppShell>
      <Recorder initialKind={initialKind} />
    </AppShell>
  );
}
