import { NextResponse } from 'next/server';
import { getClipBySlug, renameClip, deleteClip } from '@/lib/clips';
import { deleteVideoFile } from '@/lib/storage';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/clips/:slug → single clip
export async function GET(_request, { params }) {
  try {
    const clip = await getClipBySlug(params.slug);
    if (!clip) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json({ clip });
  } catch (err) {
    return fail(err);
  }
}

// PATCH /api/clips/:slug  { title } → rename
export async function PATCH(request, { params }) {
  try {
    const { title } = await request.json();
    if (!title || !title.trim()) {
      return NextResponse.json({ error: 'Title required' }, { status: 400 });
    }
    const ok = await renameClip(params.slug, title.trim().slice(0, 255));
    if (!ok) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json({ ok: true, title: title.trim() });
  } catch (err) {
    return fail(err);
  }
}

// DELETE /api/clips/:slug → delete row + file
export async function DELETE(_request, { params }) {
  try {
    const videoPath = await deleteClip(params.slug);
    await deleteVideoFile(videoPath);
    return NextResponse.json({ ok: true });
  } catch (err) {
    return fail(err);
  }
}

function fail(err) {
  console.error('[api/clips/:slug]', err);
  return NextResponse.json({ error: 'Something went wrong.', code: err?.code }, { status: 500 });
}
