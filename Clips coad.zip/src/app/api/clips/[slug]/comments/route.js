import { NextResponse } from 'next/server';
import { getClipBySlug, listComments, addComment } from '@/lib/clips';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/clips/:slug/comments → list
export async function GET(_request, { params }) {
  try {
    const clip = await getClipBySlug(params.slug);
    if (!clip) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    const comments = await listComments(clip.id);
    return NextResponse.json({ comments });
  } catch (err) {
    return fail(err);
  }
}

// POST /api/clips/:slug/comments  { body, authorName?, tsSeconds? }
export async function POST(request, { params }) {
  try {
    const clip = await getClipBySlug(params.slug);
    if (!clip) return NextResponse.json({ error: 'Not found' }, { status: 404 });

    const { body, authorName, tsSeconds } = await request.json();
    if (!body || !body.trim()) {
      return NextResponse.json({ error: 'Comment cannot be empty' }, { status: 400 });
    }
    const comment = await addComment(clip.id, {
      authorName: (authorName || 'Guest').toString().slice(0, 120),
      body: body.trim().slice(0, 2000),
      tsSeconds: Number.isFinite(tsSeconds) ? Math.round(tsSeconds) : null,
    });
    return NextResponse.json({ comment }, { status: 201 });
  } catch (err) {
    return fail(err);
  }
}

function fail(err) {
  console.error('[api/clips/:slug/comments]', err);
  return NextResponse.json({ error: 'Something went wrong.', code: err?.code }, { status: 500 });
}
