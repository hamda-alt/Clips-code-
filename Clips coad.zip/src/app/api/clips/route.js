import { NextResponse } from 'next/server';
import { nanoid } from 'nanoid';
import { listClips, searchClips, createClip, getDefaultAuthorId } from '@/lib/clips';
import { saveVideoFile } from '@/lib/storage';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const KINDS = ['video', 'voice', 'syncup', 'meeting'];

// GET /api/clips?kind=video|voice|syncup|meeting   → list clips (newest first)
// GET /api/clips?q=text                            → search titles + transcripts
export async function GET(request) {
  try {
    const params = new URL(request.url).searchParams;
    const q = (params.get('q') || '').trim();
    if (q) return NextResponse.json({ clips: await searchClips(q) });

    const kindParam = params.get('kind');
    const kind = KINDS.includes(kindParam) ? kindParam : undefined;
    return NextResponse.json({ clips: await listClips({ kind }) });
  } catch (err) {
    return dbError(err);
  }
}

// POST /api/clips  (multipart/form-data)
// fields: video (Blob), title, duration, resolution, kind
export async function POST(request) {
  try {
    const form = await request.formData();
    const file = form.get('video');
    if (!file || typeof file === 'string') {
      return NextResponse.json({ error: 'Missing "video" file.' }, { status: 400 });
    }

    const kind = KINDS.includes(form.get('kind')) ? form.get('kind') : 'video';
    const defaultPrefix = kind === 'voice' ? 'voice-note' : kind === 'syncup' ? 'syncup' : 'screen-recording';
    const title =
      (form.get('title') || '').toString().trim() ||
      `${defaultPrefix}-${new Date().toISOString().slice(0, 16).replace('T', '-').replace(':', '-')}`;
    const duration = Number(form.get('duration') || 0);
    const resolution = (form.get('resolution') || '1080p').toString();

    const mimeType = file.type || (kind === 'voice' ? 'audio/webm' : 'video/webm');
    const ext = mimeType.includes('mp4') ? 'mp4' : mimeType.includes('audio') ? 'weba' : 'webm';

    // Optional AI metadata (JSON strings) — a transcription step can attach these.
    const parseJson = (key) => {
      try {
        const raw = form.get(key);
        return raw ? JSON.parse(raw.toString()) : null;
      } catch {
        return null;
      }
    };

    const slug = nanoid(12);
    const buffer = Buffer.from(await file.arrayBuffer());
    const videoPath = await saveVideoFile(slug, buffer, ext);
    const authorId = await getDefaultAuthorId();

    await createClip({
      slug,
      title,
      kind,
      videoPath,
      mimeType,
      duration: Math.round(duration),
      sizeBytes: buffer.length,
      resolution,
      authorId,
      summary: (form.get('summary') || '').toString() || null,
      participants: parseJson('participants'),
      transcript: parseJson('transcript'),
      actionItems: parseJson('actionItems'),
    });

    return NextResponse.json({ slug, title, videoPath }, { status: 201 });
  } catch (err) {
    return dbError(err);
  }
}

function dbError(err) {
  console.error('[api/clips]', err);
  const isConn =
    err?.code === 'ECONNREFUSED' ||
    err?.code === 'ER_BAD_DB_ERROR' ||
    err?.code === 'ER_ACCESS_DENIED_ERROR';
  return NextResponse.json(
    {
      error: isConn
        ? 'Cannot reach MySQL. Check your DB_* env vars and run `npm run db:setup`.'
        : 'Something went wrong.',
      code: err?.code,
    },
    { status: isConn ? 503 : 500 },
  );
}
