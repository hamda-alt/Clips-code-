import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="grid h-screen place-items-center bg-ink-950 px-6 text-center">
      <div>
        <p className="text-sm font-medium uppercase tracking-widest text-brand">404</p>
        <h1 className="mt-2 text-2xl font-semibold">This clip isn’t here</h1>
        <p className="mt-2 text-sm text-muted">
          It may have been deleted, or the link is wrong.
        </p>
        <Link
          href="/"
          className="mt-6 inline-block rounded-lg bg-white px-5 py-2.5 text-sm font-semibold text-ink-950 transition hover:bg-white/90"
        >
          Back to Clips
        </Link>
      </div>
    </div>
  );
}
