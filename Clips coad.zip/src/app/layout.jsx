import './globals.css';
import { Inter } from 'next/font/google';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

export const metadata = {
  title: 'Clips — Record & share in a snap',
  description:
    'Capture your screen, get a shareable link instantly, and skip the meeting. A Loom/Cap-style clips app built with Next.js + MySQL.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={inter.variable}>
      <body>{children}</body>
    </html>
  );
}
