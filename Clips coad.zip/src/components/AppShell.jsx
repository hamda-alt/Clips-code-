import Sidebar from './Sidebar';
import TopBar from './TopBar';
import RecordLauncher from './RecordLauncher';

export default function AppShell({ children, counts, activeKind }) {
  return (
    <div className="flex h-screen overflow-hidden bg-ink-950">
      <Sidebar counts={counts} activeKind={activeKind} />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar />
        <main className="flex-1 overflow-y-auto px-5 py-6 md:px-8">
          <div className="mx-auto max-w-6xl">{children}</div>
        </main>
      </div>
      <RecordLauncher />
    </div>
  );
}
