'use client';

import { useState } from 'react';
import { LinkIcon, CheckIcon } from './icons';

export default function CopyLinkButton({ slug }) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    const url = `${window.location.origin}/clip/${slug}`;
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      // Fallback for insecure contexts.
      const t = document.createElement('textarea');
      t.value = url;
      document.body.appendChild(t);
      t.select();
      document.execCommand('copy');
      document.body.removeChild(t);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  }

  return (
    <button
      onClick={copy}
      className="flex items-center gap-1.5 rounded-lg border border-ink-700 px-3 py-1.5 text-sm text-white/80 transition hover:bg-ink-850"
    >
      {copied ? (
        <>
          <CheckIcon width={15} height={15} className="text-emerald-400" />
          Copied
        </>
      ) : (
        <>
          <LinkIcon width={15} height={15} />
          Copy link
        </>
      )}
    </button>
  );
}
