'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import {
  PlayIcon,
  PauseIcon,
  VolumeIcon,
  MuteIcon,
  FullscreenIcon,
  CcIcon,
} from './icons';
import { formatDuration } from '@/lib/format';

const SPEEDS = [1, 1.2, 1.5, 2, 0.5];

export default function VideoPlayer({ src, poster }) {
  const videoRef = useRef(null);
  const wrapRef = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [speedIdx, setSpeedIdx] = useState(0);
  const [cc, setCc] = useState(true);
  const [ready, setReady] = useState(false);

  const speed = SPEEDS[speedIdx];

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play();
    else v.pause();
  }, []);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onTime = () => setCurrent(v.currentTime);
    const onLoaded = () => {
      // Some webm blobs report Infinity until seeked; guard against it.
      setDuration(Number.isFinite(v.duration) ? v.duration : 0);
      setReady(true);
    };
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    v.addEventListener('timeupdate', onTime);
    v.addEventListener('loadedmetadata', onLoaded);
    v.addEventListener('durationchange', onLoaded);
    v.addEventListener('play', onPlay);
    v.addEventListener('pause', onPause);
    return () => {
      v.removeEventListener('timeupdate', onTime);
      v.removeEventListener('loadedmetadata', onLoaded);
      v.removeEventListener('durationchange', onLoaded);
      v.removeEventListener('play', onPlay);
      v.removeEventListener('pause', onPause);
    };
  }, []);

  useEffect(() => {
    if (videoRef.current) videoRef.current.playbackRate = speed;
  }, [speed]);

  // Keyboard shortcuts (space / arrows / m / f).
  useEffect(() => {
    const onKey = (e) => {
      if (['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) return;
      const v = videoRef.current;
      if (!v) return;
      if (e.key === ' ' || e.key === 'k') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'ArrowRight') {
        v.currentTime = Math.min(v.duration || 0, v.currentTime + 5);
      } else if (e.key === 'ArrowLeft') {
        v.currentTime = Math.max(0, v.currentTime - 5);
      } else if (e.key === 'm') {
        v.muted = !v.muted;
        setMuted(v.muted);
      } else if (e.key === 'f') {
        toggleFullscreen();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [togglePlay]);

  function seek(e) {
    const v = videoRef.current;
    const value = Number(e.target.value);
    if (v && duration) {
      v.currentTime = (value / 100) * duration;
      setCurrent(v.currentTime);
    }
  }

  function toggleMute() {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setMuted(v.muted);
  }

  function toggleFullscreen() {
    const el = wrapRef.current;
    if (!el) return;
    if (document.fullscreenElement) document.exitFullscreen();
    else el.requestFullscreen?.();
  }

  const pct = duration ? (current / duration) * 100 : 0;

  return (
    <div
      ref={wrapRef}
      className="group relative overflow-hidden rounded-2xl border border-ink-700 bg-black"
    >
      <video
        ref={videoRef}
        src={src}
        poster={poster}
        playsInline
        onClick={togglePlay}
        className="aspect-video w-full bg-black"
      />

      {/* Center play button */}
      {!playing && (
        <button
          onClick={togglePlay}
          className="absolute inset-0 grid place-items-center"
          aria-label="Play"
        >
          <span className="grid h-16 w-16 place-items-center rounded-full bg-white/95 text-ink-950 shadow-pop transition hover:scale-105">
            <PlayIcon width={26} height={26} className="ml-1" />
          </span>
        </button>
      )}

      {/* Simulated live caption line (the reference clip shows auto-captions) */}
      {cc && playing && (
        <div className="pointer-events-none absolute inset-x-0 bottom-16 flex justify-center px-4">
          <span className="rounded-md bg-black/70 px-3 py-1.5 text-center text-sm text-white/95">
            Auto-generated captions appear here while the clip plays.
          </span>
        </div>
      )}

      {/* Controls */}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent px-4 pb-3 pt-10 opacity-100 transition group-hover:opacity-100">
        <input
          type="range"
          min={0}
          max={100}
          step={0.1}
          value={pct}
          onChange={seek}
          className="scrubber w-full"
          style={{
            background: `linear-gradient(to right, #e5352b ${pct}%, rgba(255,255,255,0.18) ${pct}%)`,
          }}
          aria-label="Seek"
        />
        <div className="mt-2 flex items-center gap-3 text-white/90">
          <button onClick={togglePlay} className="transition hover:text-white" aria-label="Play/Pause">
            {playing ? <PauseIcon width={20} height={20} /> : <PlayIcon width={20} height={20} />}
          </button>
          <button onClick={toggleMute} className="transition hover:text-white" aria-label="Mute">
            {muted ? <MuteIcon width={20} height={20} /> : <VolumeIcon width={20} height={20} />}
          </button>
          <span className="text-xs tabular-nums text-white/80">
            {formatDuration(current)} / {formatDuration(duration)}
          </span>

          <span className="flex-1" />

          <button
            onClick={() => setCc((v) => !v)}
            className={`transition hover:text-white ${cc ? 'text-white' : 'text-white/40'}`}
            aria-label="Captions"
            title="Captions"
          >
            <CcIcon width={22} height={22} />
          </button>
          <button
            onClick={() => setSpeedIdx((i) => (i + 1) % SPEEDS.length)}
            className="rounded bg-white/10 px-2 py-0.5 text-xs font-medium tabular-nums transition hover:bg-white/20"
            title="Playback speed"
          >
            {speed}×
          </button>
          <button
            onClick={toggleFullscreen}
            className="transition hover:text-white"
            aria-label="Fullscreen"
          >
            <FullscreenIcon width={20} height={20} />
          </button>
        </div>
      </div>

      {!ready && (
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <span className="h-6 w-6 animate-spin rounded-full border-2 border-white/30 border-t-white" />
        </div>
      )}
    </div>
  );
}
