import RecordTrigger from './RecordTrigger';
import { RecordIcon } from './icons';

// Minimal top bar — just the New Clip action, right-aligned.
export default function TopBar() {
  return (
    <header className="flex h-14 shrink-0 items-center justify-end border-b border-ink-700 bg-ink-950/80 px-4 backdrop-blur">
      <RecordTrigger className="flex items-center gap-2 rounded-lg bg-brand px-3 py-1.5 text-sm font-medium text-white shadow-sm transition hover:bg-brand-hover">
        <RecordIcon width={16} height={16} />
        <span>New Clip</span>
      </RecordTrigger>
    </header>
  );
}
