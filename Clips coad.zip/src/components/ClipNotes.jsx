'use client';

import { useState } from 'react';
import { SparkIcon, SyncIcon, CheckIcon } from './icons';
import { formatDuration } from '@/lib/format';

// mysql2 returns JSON columns already parsed, but guard against string values.
function asArray(v) {
  if (Array.isArray(v)) return v;
  if (typeof v === 'string') {
    try {
      const p = JSON.parse(v);
      return Array.isArray(p) ? p : [];
    } catch {
      return [];
    }
  }
  return [];
}

export default function ClipNotes({ clip }) {
  if (clip.kind === 'meeting') return <AiNotes clip={clip} />;
  if (clip.kind === 'syncup') return <SyncUpNotes clip={clip} />;
  return null;
}

function AiNotes({ clip }) {
  const [tab, setTab] = useState('summary');
  const transcript = asArray(clip.transcript);
  const actions = asArray(clip.action_items);

  const hasAnything = clip.summary || transcript.length || actions.length;
  if (!hasAnything) return null;

  return (
    <div className="mt-6 overflow-hidden rounded-2xl border border-ink-700 bg-ink-850">
      <div className="flex items-center gap-2 border-b border-ink-700 px-4 py-3.5 text-sm font-semibold">
        <SparkIcon width={16} height={16} className="text-purple-400" />
        AI Notes
        <span className="ml-auto rounded-md bg-purple-500/10 px-2 py-0.5 text-[10px] font-medium text-purple-300">
          Auto-generated
        </span>
      </div>

      <div className="flex gap-1 px-3 pt-2.5">
        {[
          ['summary', 'Summary'],
          ['transcript', 'Transcript'],
          ['actions', 'Action items'],
        ].map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`rounded-t-lg border-b-2 px-3 py-2 text-sm font-medium transition ${
              tab === id ? 'border-brand text-white' : 'border-transparent text-muted hover:text-white'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="p-4">
        {tab === 'summary' && (
          <p className="text-sm leading-relaxed text-white/80">
            {clip.summary || 'No summary available.'}
          </p>
        )}
        {tab === 'transcript' && (
          <div className="flex flex-col gap-1">
            {transcript.length === 0 ? (
              <p className="text-sm text-faint">No transcript.</p>
            ) : (
              transcript.map((r, i) => (
                <div key={i} className="flex gap-3 rounded-lg px-2 py-2">
                  <span className="min-w-[38px] pt-0.5 text-xs tabular-nums text-brand">
                    {formatDuration(r.t || 0)}
                  </span>
                  <div>
                    <span className="text-xs font-semibold text-white/80">{r.speaker}</span>
                    <p className="mt-0.5 text-sm text-white/70">{r.text}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
        {tab === 'actions' && (
          <div className="flex flex-col gap-2">
            {actions.length === 0 ? (
              <p className="text-sm text-faint">No action items.</p>
            ) : (
              actions.map((a, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <span className="mt-0.5 grid h-5 w-5 place-items-center rounded-md bg-emerald-500/15 text-emerald-400">
                    <CheckIcon width={13} height={13} />
                  </span>
                  <p className="text-sm text-white/70">
                    <b className="text-white/90">{a.who}</b> — {a.text}
                  </p>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function SyncUpNotes({ clip }) {
  const participants = asArray(clip.participants);
  const transcript = asArray(clip.transcript);
  if (participants.length === 0 && transcript.length === 0) return null;

  return (
    <div className="mt-6 overflow-hidden rounded-2xl border border-ink-700 bg-ink-850">
      <div className="flex items-center gap-2 border-b border-ink-700 px-4 py-3.5 text-sm font-semibold">
        <SyncIcon width={16} height={16} className="text-indigo-400" />
        SyncUp call
        <span className="ml-auto rounded-md bg-indigo-500/10 px-2 py-0.5 text-[10px] font-medium text-indigo-300">
          Recorded
        </span>
      </div>
      <div className="p-4">
        <div className="flex flex-wrap gap-2">
          {participants.map((n, i) => (
            <span
              key={i}
              className="inline-flex items-center gap-2 rounded-full border border-ink-700 bg-ink-900 py-1 pl-1 pr-3 text-xs text-white/80"
            >
              <span className="grid h-5 w-5 place-items-center rounded-full bg-gradient-to-br from-brand to-orange-500 text-[9px] font-bold text-white">
                {String(n).charAt(0).toUpperCase()}
              </span>
              {n}
            </span>
          ))}
        </div>
        {transcript.length > 0 && (
          <div className="mt-4 flex flex-col gap-1">
            {transcript.map((r, i) => (
              <div key={i} className="flex gap-3 rounded-lg px-2 py-2">
                <span className="min-w-[38px] pt-0.5 text-xs tabular-nums text-brand">
                  {formatDuration(r.t || 0)}
                </span>
                <div>
                  <span className="text-xs font-semibold text-white/80">{r.speaker}</span>
                  <p className="mt-0.5 text-sm text-white/70">{r.text}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
