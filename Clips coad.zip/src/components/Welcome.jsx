import RecordTrigger from './RecordTrigger';
import { RecordIcon } from './icons';

const CARDS = [
  {
    title: 'Record in a snap',
    body:
      'Capture your device’s screen with just a few clicks. Record and effortlessly share your videos with anyone.',
    art: <RecordArt />,
  },
  {
    title: 'Unlock async productivity',
    body:
      'Skip the meetings and share all of your design updates, feedback videos, onboarding videos, and more in one place.',
    art: <GridArt />,
  },
  {
    title: 'Watch, share, collaborate',
    body:
      'Clips automatically generates a link, allowing you to quickly share your clips anywhere, even outside of your Workspace.',
    art: <ShareArt />,
  },
];

export default function Welcome() {
  return (
    <section className="animate-fadeIn">
      <h1 className="mb-6 text-2xl font-semibold tracking-tight">Welcome to Clips</h1>

      <div className="grid gap-4 lg:grid-cols-3">
        {CARDS.map((c) => (
          // Every card opens the record-options popover.
          <RecordTrigger
            key={c.title}
            className="block cursor-pointer rounded-2xl border border-ink-700 bg-ink-850 p-5 text-left transition hover:border-brand"
          >
            <h3 className="text-[15px] font-semibold text-white">{c.title}</h3>
            <p className="mt-1.5 text-[13px] leading-relaxed text-muted">{c.body}</p>
            <div className="mt-4 overflow-hidden rounded-xl border border-ink-700 bg-ink-950">{c.art}</div>
          </RecordTrigger>
        ))}
      </div>

      <div className="mx-auto mt-10 max-w-xl text-center">
        <h2 className="text-lg font-semibold">Create your first Clip!</h2>
        <p className="mx-auto mt-1.5 max-w-md text-[13px] leading-relaxed text-muted">
          Create and share screen recordings to give your teammates context. Save your recordings,
          attach them to tasks, or share them anywhere.
        </p>
        <RecordTrigger className="mt-5 inline-flex items-center gap-2 rounded-lg bg-white px-5 py-2.5 text-sm font-semibold text-ink-950 transition hover:bg-white/90">
          <RecordIcon width={16} height={16} className="text-brand" />
          Create Clip
        </RecordTrigger>
      </div>
    </section>
  );
}

/* ---- Decorative mockups (pure CSS, no assets) ---------------------------- */

function RecordArt() {
  return (
    <div className="space-y-2 p-4">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-medium tracking-wide text-faint">RECORD CLIP</span>
        <span className="rounded bg-ink-800 px-2 py-0.5 text-[9px] text-muted">Go to Clips</span>
      </div>
      <Row label="MacBook Pro Microphone" />
      <Row label="Full Screen" />
      <div className="flex items-center justify-center gap-2 rounded-md bg-brand py-2 text-[11px] font-semibold text-white">
        <span className="h-2 w-2 rounded-full bg-white animate-pulseRec" />
        Start recording
      </div>
    </div>
  );
}

function Row({ label }) {
  return (
    <div className="flex items-center gap-2 rounded-md bg-ink-850 px-2.5 py-2">
      <span className="h-2.5 w-2.5 rounded-full border border-faint" />
      <span className="flex-1 text-[11px] text-muted">{label}</span>
      <span className="flex gap-0.5">
        {[3, 6, 4, 8, 5].map((h, i) => (
          <span key={i} className="w-0.5 rounded-full bg-brand/70" style={{ height: h }} />
        ))}
      </span>
    </div>
  );
}

function GridArt() {
  return (
    <div className="p-4">
      <span className="mb-2 block text-[10px] text-faint">My clips</span>
      <div className="grid grid-cols-3 gap-2">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="space-y-1">
            <div
              className="aspect-video rounded-md bg-gradient-to-br from-indigo-500/40 to-purple-600/30"
              style={{ opacity: 0.5 + (i % 3) * 0.18 }}
            />
            <div className="h-1 w-3/4 rounded bg-ink-700" />
          </div>
        ))}
      </div>
    </div>
  );
}

function ShareArt() {
  return (
    <div className="space-y-2 p-4">
      <div className="flex items-center justify-between">
        <span className="text-[10px] text-faint">Product Update · Dec 12</span>
        <span className="rounded bg-emerald-500/80 px-2 py-0.5 text-[9px] font-medium text-white">
          Share
        </span>
      </div>
      <div className="aspect-video rounded-md bg-gradient-to-br from-emerald-500/30 to-teal-600/20" />
      <div className="flex gap-2">
        <div className="h-1.5 flex-1 rounded bg-ink-700" />
        <div className="h-1.5 w-8 rounded bg-emerald-500/60" />
      </div>
    </div>
  );
}
