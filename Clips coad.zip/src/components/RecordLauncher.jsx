'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  RecordIcon,
  MicIcon,
  ScreenIcon,
  VideoIcon,
  ChevronDown,
  CheckIcon,
} from './icons';
import { formatDuration } from '@/lib/format';

const SOURCES = [
  { id: 'monitor', label: 'Entire screen', icon: ScreenIcon },
  { id: 'window', label: 'Window', icon: VideoIcon },
];
const RESOLUTIONS = [
  { id: '720p', label: '720p', tag: 'HD', height: 720 },
  { id: '1080p', label: '1080p', tag: 'Full HD', height: 1080 },
  { id: '1440p', label: '1440p', tag: '2K', height: 1440, locked: true },
  { id: '2160p', label: '2160p', tag: '4K', height: 2160, locked: true },
  { id: 'native', label: 'Native', tag: 'Auto', height: 0 },
];

// A single launcher mounted in the shell. Any "record" trigger dispatches
// window event `clips:record` to open this popover (matching ClickUp).
export default function RecordLauncher() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [phase, setPhase] = useState('idle'); // idle | recording | preview | uploading
  const [source, setSource] = useState('monitor');
  const [resolution, setResolution] = useState('1080p');
  const [mics, setMics] = useState([]);
  const [micId, setMicId] = useState('default'); // 'off' | 'default' | deviceId
  const [elapsed, setElapsed] = useState(0);
  const [error, setError] = useState('');
  const [previewUrl, setPreviewUrl] = useState('');
  const [title, setTitle] = useState('');
  const [progress, setProgress] = useState(0);

  const recRef = useRef(null);
  const chunksRef = useRef([]);
  const displayRef = useRef(null);
  const micRef = useRef(null);
  const timerRef = useRef(null);
  const blobRef = useRef(null);
  const popRef = useRef(null);

  const openPopover = useCallback(() => {
    setError('');
    setOpen(true);
    setPhase('idle');
  }, []);

  useEffect(() => {
    const h = () => openPopover();
    window.addEventListener('clips:record', h);
    return () => window.removeEventListener('clips:record', h);
  }, [openPopover]);

  // Enumerate microphones when the popover opens.
  useEffect(() => {
    if (!open) return;
    navigator.mediaDevices?.enumerateDevices?.().then((list) => {
      setMics(list.filter((d) => d.kind === 'audioinput' && d.deviceId));
    }).catch(() => {});
  }, [open]);

  // Close on outside click / Esc while idle.
  useEffect(() => {
    if (!open || phase !== 'idle') return;
    const onClick = (e) => popRef.current && !popRef.current.contains(e.target) && setOpen(false);
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [open, phase]);

  useEffect(() => () => cleanup(), []);

  function cleanup() {
    clearInterval(timerRef.current);
    displayRef.current?.getTracks().forEach((t) => t.stop());
    micRef.current?.getTracks().forEach((t) => t.stop());
    displayRef.current = null;
    micRef.current = null;
  }

  async function startRecording() {
    setError('');
    if (!navigator.mediaDevices?.getDisplayMedia) {
      setError('Screen recording needs Chrome or Edge.');
      return;
    }
    const chosen = RESOLUTIONS.find((r) => r.id === resolution);
    if (chosen?.locked) setError('2K/4K needs the Business plan — recording at 1080p.');
    const height = chosen?.locked ? 1080 : chosen?.height || undefined;

    try {
      const video = { displaySurface: source };
      if (height) {
        video.height = { ideal: height };
        video.frameRate = { ideal: 30 };
      }
      const display = await navigator.mediaDevices.getDisplayMedia({ video, audio: true });
      displayRef.current = display;

      let tracks = [...display.getTracks()];
      if (micId !== 'off') {
        try {
          const mic = await navigator.mediaDevices.getUserMedia({
            audio: micId === 'default' ? true : { deviceId: { exact: micId } },
          });
          micRef.current = mic;
          tracks = [...display.getVideoTracks(), ...display.getAudioTracks(), ...mic.getAudioTracks()];
        } catch {
          /* mic denied — screen only */
        }
      }
      const stream = new MediaStream(tracks);
      const mime =
        ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].find(
          (t) => MediaRecorder.isTypeSupported(t),
        ) || '';
      const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      chunksRef.current = [];
      rec.ondataavailable = (e) => e.data && e.data.size && chunksRef.current.push(e.data);
      rec.onstop = onStop;
      recRef.current = rec;
      display.getVideoTracks()[0].addEventListener('ended', () => {
        if (recRef.current?.state === 'recording') recRef.current.stop();
      });
      rec.start(250);
      setPhase('recording');
      setElapsed(0);
      timerRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    } catch (err) {
      setError(err?.name === 'NotAllowedError' ? 'Screen share was cancelled.' : 'Couldn’t start: ' + (err?.message || ''));
      cleanup();
    }
  }

  const durRef = useRef(0);
  function stopRecording() {
    durRef.current = elapsed;
    clearInterval(timerRef.current);
    if (recRef.current?.state !== 'inactive') recRef.current?.stop();
  }
  function onStop() {
    cleanup();
    const blob = new Blob(chunksRef.current, { type: recRef.current?.mimeType || 'video/webm' });
    blobRef.current = blob;
    setPreviewUrl(URL.createObjectURL(blob));
    setTitle(defaultTitle());
    setPhase('preview');
  }

  async function save() {
    if (!blobRef.current) return;
    setPhase('uploading');
    setProgress(0);
    const form = new FormData();
    form.append('video', blobRef.current, 'clip.webm');
    form.append('title', title.trim() || defaultTitle());
    form.append('duration', String(durRef.current || elapsed));
    form.append('resolution', resolution);
    form.append('kind', 'video');
    try {
      const slug = await upload('/api/clips', form, setProgress);
      reset();
      router.push(`/clip/${slug}`);
    } catch (e) {
      setError('Upload failed.');
      setPhase('preview');
    }
  }
  function reset() {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl('');
    blobRef.current = null;
    setOpen(false);
    setPhase('idle');
    setElapsed(0);
    setError('');
  }

  if (!open) return null;

  // Recording bar (top center)
  if (phase === 'recording') {
    return (
      <div className="fixed left-1/2 top-4 z-[130] flex -translate-x-1/2 items-center gap-3 rounded-full border border-ink-700 bg-ink-900 px-4 py-2 shadow-pop">
        <span className="h-3 w-3 rounded-full bg-brand animate-pulseRec" />
        <span className="text-sm font-semibold tabular-nums">{formatDuration(elapsed)}</span>
        <button
          onClick={stopRecording}
          className="flex items-center gap-1.5 rounded-lg bg-brand px-3 py-1 text-sm font-semibold text-white transition hover:bg-brand-hover"
        >
          <span className="h-2.5 w-2.5 rounded-[2px] bg-white" /> Stop
        </button>
      </div>
    );
  }

  // Preview modal
  if (phase === 'preview' || phase === 'uploading') {
    const uploading = phase === 'uploading';
    return (
      <div className="fixed inset-0 z-[130] grid place-items-center bg-black/55 p-4">
        <div className="w-full max-w-lg animate-fadeIn rounded-2xl border border-ink-700 bg-ink-900 p-5">
          <h2 className="mb-3 text-base font-semibold">Review your clip</h2>
          <div className="overflow-hidden rounded-xl border border-ink-700 bg-black">
            <video src={previewUrl} controls playsInline className="aspect-video w-full" />
          </div>
          <input
            value={title}
            disabled={uploading}
            onChange={(e) => setTitle(e.target.value)}
            className="mt-4 w-full rounded-lg border border-ink-700 bg-ink-950 px-3 py-2.5 text-sm text-white outline-none focus:border-brand"
          />
          {error && <p className="mt-2 text-sm text-brand">{error}</p>}
          {uploading ? (
            <div className="mt-4">
              <div className="h-2 overflow-hidden rounded-full bg-ink-800">
                <div className="h-full rounded-full bg-brand transition-all" style={{ width: `${progress}%` }} />
              </div>
              <p className="mt-2 text-center text-sm text-muted">Uploading… {progress}%</p>
            </div>
          ) : (
            <div className="mt-4 flex gap-3">
              <button onClick={save} className="flex-1 rounded-lg bg-brand px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-brand-hover">
                Save &amp; get link
              </button>
              <button onClick={reset} className="rounded-lg border border-ink-700 px-4 py-2.5 text-sm text-muted transition hover:bg-ink-850 hover:text-white">
                Discard
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Idle popover (top-right, like ClickUp)
  const curMicLabel =
    micId === 'off'
      ? 'No microphone'
      : micId === 'default'
        ? 'Default microphone'
        : mics.find((m) => m.deviceId === micId)?.label || 'Microphone';

  return (
    <div ref={popRef} className="fixed right-4 top-[60px] z-[130] w-72 animate-fadeIn rounded-xl border border-ink-700 bg-ink-900 p-2 shadow-pop">
      <Dropdown
        icon={ScreenIcon}
        value={SOURCES.find((s) => s.id === source)?.label}
        options={SOURCES.map((s) => ({ id: s.id, label: s.label, icon: s.icon }))}
        onSelect={setSource}
        selected={source}
      />
      <Dropdown
        icon={ChevronDown}
        value={
          <span className="flex items-center gap-2">
            {RESOLUTIONS.find((r) => r.id === resolution)?.label}
            <span className="text-[11px] text-faint">{RESOLUTIONS.find((r) => r.id === resolution)?.tag}</span>
          </span>
        }
        options={RESOLUTIONS.map((r) => ({
          id: r.id,
          label: (
            <span className="flex items-center gap-2">
              {r.label}
              <span className="text-[11px] text-faint">{r.tag}</span>
              {r.locked && <span className="ml-auto rounded bg-brand/15 px-1.5 py-0.5 text-[10px] text-brand">Upgrade</span>}
            </span>
          ),
        }))}
        onSelect={setResolution}
        selected={resolution}
      />
      <Dropdown
        icon={MicIcon}
        value={curMicLabel}
        options={[
          { id: 'off', label: 'No microphone' },
          { id: 'default', label: 'Default microphone' },
          ...mics.map((m) => ({ id: m.deviceId, label: m.label || 'Microphone' })),
        ]}
        onSelect={setMicId}
        selected={micId}
      />
      {error && <p className="px-1 py-1 text-xs text-brand">{error}</p>}
      <button
        onClick={startRecording}
        className="mt-1 flex w-full items-center justify-center gap-2 rounded-lg bg-brand px-3 py-2.5 text-sm font-semibold text-white transition hover:bg-brand-hover"
      >
        <RecordIcon width={16} height={16} /> Record Clip
        <kbd className="ml-1 rounded bg-white/15 px-1.5 py-0.5 text-[10px]">Ctrl+Alt+S</kbd>
      </button>
    </div>
  );
}

function Dropdown({ icon: Icon, value, options, onSelect, selected }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return;
    const h = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false);
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [open]);
  return (
    <div className="relative mb-1" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm text-white/90 transition hover:bg-ink-850"
      >
        <Icon width={16} height={16} className="text-muted" />
        <span className="min-w-0 flex-1 truncate text-left">{value}</span>
        <ChevronDown width={15} height={15} className="text-faint" />
      </button>
      {open && (
        <div className="absolute left-0 right-0 top-full z-10 mt-1 animate-fadeIn overflow-hidden rounded-lg border border-ink-700 bg-ink-850 py-1 shadow-pop">
          {options.map((o) => (
            <button
              key={o.id}
              onClick={() => {
                onSelect(o.id);
                setOpen(false);
              }}
              className="flex w-full items-center gap-2 px-2.5 py-2 text-sm text-white/85 transition hover:bg-ink-800"
            >
              <span className="w-4">{selected === o.id && <CheckIcon width={14} height={14} className="text-brand" />}</span>
              {o.icon && <o.icon width={15} height={15} className="text-muted" />}
              <span className="min-w-0 flex-1 truncate text-left">{o.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function defaultTitle() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `screen-recording-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}-${p(d.getMinutes())}`;
}

function upload(url, formData, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          resolve(JSON.parse(xhr.responseText).slug);
        } catch {
          reject(new Error('bad response'));
        }
      } else reject(new Error('failed'));
    };
    xhr.onerror = () => reject(new Error('network'));
    xhr.send(formData);
  });
}
