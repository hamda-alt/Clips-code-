'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { DotsIcon, PlayIcon, PencilIcon, DownloadIcon, TrashIcon, MicIcon, SparkIcon, SyncIcon, VideoIcon } from './icons';
import { formatDuration, timeAgo, kindLabel } from '@/lib/format';

function KindMark({ kind }) {
  const color =
    kind === 'voice' ? 'text-brand' : kind === 'syncup' ? 'text-indigo-400' : kind === 'meeting' ? 'text-purple-400' : 'text-brand';
  const Icon = kind === 'voice' ? MicIcon : kind === 'syncup' ? SyncIcon : kind === 'meeting' ? SparkIcon : VideoIcon;
  return <Icon width={13} height={13} className={color} />;
}

export default function ClipCard({ clip }) {
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const [title, setTitle] = useState(clip.title);
  const [busy, setBusy] = useState(false);
  const menuRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (!menuOpen) return;
    const onClick = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, [menuOpen]);

  useEffect(() => {
    if (renaming) inputRef.current?.focus();
  }, [renaming]);

  async function submitRename() {
    const next = title.trim();
    setRenaming(false);
    if (!next || next === clip.title) {
      setTitle(clip.title);
      return;
    }
    setBusy(true);
    await fetch(`/api/clips/${clip.slug}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: next }),
    });
    setBusy(false);
    router.refresh();
  }

  async function remove() {
    if (!confirm(`Delete “${clip.title}”? This can’t be undone.`)) return;
    setBusy(true);
    await fetch(`/api/clips/${clip.slug}`, { method: 'DELETE' });
    setBusy(false);
    router.refresh();
  }

  const isVoice = clip.kind === 'voice';

  return (
    <div
      className={`group relative overflow-hidden rounded-xl border border-ink-700 bg-ink-850 transition hover:border-ink-600 ${
        busy ? 'opacity-50' : ''
      }`}
    >
      <Link href={`/clip/${clip.slug}`} className="block">
        <div className="relative aspect-video overflow-hidden bg-ink-950">
          {isVoice ? (
            <div className="grid h-full place-items-center bg-gradient-to-br from-brand/20 to-purple-600/10">
              <MicIcon width={34} height={34} className="text-brand" />
            </div>
          ) : (
            <video
              src={`${clip.video_path}#t=0.1`}
              preload="metadata"
              muted
              playsInline
              className="h-full w-full object-cover"
            />
          )}
          {clip.kind === 'meeting' && (
            <span className="absolute left-2 top-2 inline-flex items-center gap-1 rounded-md bg-black/60 px-1.5 py-0.5 text-[10px] font-semibold text-white">
              <SparkIcon width={11} height={11} /> AI Notes
            </span>
          )}
          {clip.kind === 'syncup' && (
            <span className="absolute left-2 top-2 inline-flex items-center gap-1 rounded-md bg-black/60 px-1.5 py-0.5 text-[10px] font-semibold text-white">
              <SyncIcon width={11} height={11} /> SyncUp
            </span>
          )}
          <div className="absolute inset-0 grid place-items-center bg-black/0 transition group-hover:bg-black/30">
            <span className="grid h-11 w-11 place-items-center rounded-full bg-white/95 text-ink-950 opacity-0 shadow-pop transition group-hover:opacity-100">
              <PlayIcon width={18} height={18} className="ml-0.5" />
            </span>
          </div>
          {clip.duration > 0 && (
            <span className="absolute bottom-2 right-2 rounded bg-black/70 px-1.5 py-0.5 text-[11px] font-medium tabular-nums text-white">
              {formatDuration(clip.duration)}
            </span>
          )}
        </div>
      </Link>

      <div className="flex items-start gap-2 p-3">
        <div className="min-w-0 flex-1">
          {renaming ? (
            <input
              ref={inputRef}
              value={title}
              disabled={busy}
              onChange={(e) => setTitle(e.target.value)}
              onBlur={submitRename}
              onKeyDown={(e) => {
                if (e.key === 'Enter') submitRename();
                if (e.key === 'Escape') {
                  setTitle(clip.title);
                  setRenaming(false);
                }
              }}
              className="w-full rounded border border-brand/60 bg-ink-950 px-1.5 py-0.5 text-sm text-white outline-none"
            />
          ) : (
            <p className="truncate text-sm font-medium text-white/90">{clip.title}</p>
          )}
          <p className="mt-0.5 flex items-center gap-1.5 truncate text-[11px] text-faint">
            <KindMark kind={clip.kind} /> {kindLabel(clip.kind)} · {timeAgo(clip.created_at)}
          </p>
        </div>

        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="grid h-7 w-7 place-items-center rounded-md text-muted opacity-0 transition hover:bg-ink-800 hover:text-white group-hover:opacity-100"
            aria-label="Clip options"
          >
            <DotsIcon width={16} height={16} />
          </button>

          {menuOpen && (
            <div className="absolute right-0 top-8 z-20 w-44 animate-fadeIn overflow-hidden rounded-lg border border-ink-700 bg-ink-900 py-1 shadow-pop">
              <MenuItem
                icon={PencilIcon}
                label="Rename"
                onClick={() => {
                  setMenuOpen(false);
                  setRenaming(true);
                }}
              />
              <a
                href={clip.video_path}
                download={`${clip.title}.${clip.video_path.split('.').pop()}`}
                onClick={() => setMenuOpen(false)}
                className="flex items-center gap-2.5 px-3 py-2 text-sm text-white/80 transition hover:bg-ink-800"
              >
                <DownloadIcon width={15} height={15} className="text-muted" />
                Download
              </a>
              <div className="my-1 h-px bg-ink-700" />
              <MenuItem icon={TrashIcon} label="Delete" danger onClick={remove} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function MenuItem({ icon: Icon, label, onClick, danger }) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm transition hover:bg-ink-800 ${
        danger ? 'text-brand' : 'text-white/80'
      }`}
    >
      <Icon width={15} height={15} className={danger ? 'text-brand' : 'text-muted'} />
      {label}
    </button>
  );
}
