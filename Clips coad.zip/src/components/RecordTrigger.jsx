'use client';

// Any element that should open the record-options popover.
// Usage: <RecordTrigger className="...">…</RecordTrigger>
export default function RecordTrigger({ className, children, title, ariaLabel }) {
  return (
    <button
      type="button"
      title={title}
      aria-label={ariaLabel}
      onClick={() => window.dispatchEvent(new Event('clips:record'))}
      className={className}
    >
      {children}
    </button>
  );
}
