'use client';

import { useEffect, useState } from 'react';
import { CommentIcon } from './icons';
import { timeAgo } from '@/lib/format';

export default function Comments({ slug }) {
  const [comments, setComments] = useState([]);
  const [body, setBody] = useState('');
  const [name, setName] = useState('');
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let active = true;
    fetch(`/api/clips/${slug}/comments`)
      .then((r) => (r.ok ? r.json() : { comments: [] }))
      .then((d) => active && setComments(d.comments || []))
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [slug]);

  async function submit(e) {
    e.preventDefault();
    if (!body.trim() || busy) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/clips/${slug}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body: body.trim(), authorName: name.trim() || 'Guest' }),
      });
      if (res.ok) {
        const { comment } = await res.json();
        setComments((c) => [...c, comment]);
        setBody('');
        setOpen(false);
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-white/90">
          <CommentIcon width={16} height={16} className="text-muted" />
          Comments
          {comments.length > 0 && (
            <span className="rounded-full bg-ink-800 px-2 text-[11px] text-muted">
              {comments.length}
            </span>
          )}
        </h3>
        <button
          onClick={() => setOpen((v) => !v)}
          className="rounded-lg border border-ink-700 px-3 py-1.5 text-xs font-medium text-white/80 transition hover:bg-ink-850"
        >
          Add comment
        </button>
      </div>

      {open && (
        <form onSubmit={submit} className="mb-5 animate-fadeIn rounded-xl border border-ink-700 bg-ink-900 p-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your name (optional)"
            className="mb-2 w-full rounded-lg border border-ink-700 bg-ink-950 px-3 py-2 text-sm outline-none focus:border-brand"
          />
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Leave a comment…"
            rows={3}
            className="w-full resize-none rounded-lg border border-ink-700 bg-ink-950 px-3 py-2 text-sm outline-none focus:border-brand"
          />
          <div className="mt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-1.5 text-xs text-muted hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={busy || !body.trim()}
              className="rounded-lg bg-brand px-4 py-1.5 text-xs font-semibold text-white transition hover:bg-brand-hover disabled:opacity-50"
            >
              {busy ? 'Posting…' : 'Post'}
            </button>
          </div>
        </form>
      )}

      {comments.length === 0 ? (
        <p className="text-sm text-faint">No comments yet. Be the first to leave one.</p>
      ) : (
        <ul className="space-y-4">
          {comments.map((c) => (
            <li key={c.id} className="flex gap-3">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-ink-800 text-xs font-semibold text-white/70">
                {(c.author_name || 'G').charAt(0).toUpperCase()}
              </span>
              <div className="min-w-0">
                <p className="text-xs text-faint">
                  <span className="font-medium text-white/80">{c.author_name}</span> ·{' '}
                  {timeAgo(c.created_at)}
                </p>
                <p className="mt-0.5 whitespace-pre-wrap break-words text-sm text-white/90">
                  {c.body}
                </p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
