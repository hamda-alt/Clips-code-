'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { MicIcon, MuteIcon, VideoIcon, ScreenIcon, PhoneIcon, SparkIcon } from './icons';
import { formatDuration } from '@/lib/format';

const TEAMMATES = [
  { name: 'Sara', color: '#6366f1' },
  { name: 'Omar', color: '#10b981' },
];

// Canned AI output (a real deployment attaches a transcription step instead).
const TRANSCRIPT = [
  { t: 0, speaker: 'Talha', text: 'Thanks for joining — quick sync on where we are.' },
  { t: 2, speaker: 'Sara', text: 'Recorder and voice notes are done and shipping.' },
  { t: 5, speaker: 'Omar', text: 'I’ll connect the share links to the database this week.' },
  { t: 8, speaker: 'Talha', text: 'Great — let’s line up the AI Notetaker beta next.' },
];
const SUMMARY =
  'The team synced on progress: the recorder and voice notes are shipping, share links will be wired to the database next, and the AI Notetaker beta is lined up after that.';
const ACTIONS = [
  { who: 'Omar', text: 'Connect share links to the database' },
  { who: 'Sara', text: 'Add captions to recorded clips' },
  { who: 'Talha', text: 'Line up the AI Notetaker beta' },
];

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

export default function SyncUpCall() {
  const router = useRouter();
  const [elapsed, setElapsed] = useState(0);
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);
  const [sharing, setSharing] = useState(false);
  const [aiOn, setAiOn] = useState(true);
  const [ending, setEnding] = useState(false);
  const [progress, setProgress] = useState(-1);

  const wrapRef = useRef(null);
  const camStreamRef = useRef(null);
  const screenStreamRef = useRef(null);
  const camVideoRef = useRef(null);
  const screenVideoRef = useRef(null);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);
  const rafRef = useRef(0);
  const timerRef = useRef(null);
  // Mirror toggle state into refs so the draw loop reads current values.
  const stateRef = useRef({ camOn: true, sharing: false });
  stateRef.current = { camOn, sharing };

  useEffect(() => {
    let cancelled = false;

    async function begin() {
      const cam = document.createElement('video');
      cam.muted = true;
      cam.playsInline = true;
      cam.autoplay = true;
      camVideoRef.current = cam;

      const screen = document.createElement('video');
      screen.muted = true;
      screen.playsInline = true;
      screen.autoplay = true;
      screenVideoRef.current = screen;

      try {
        const s = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 360 }, audio: true });
        if (cancelled) {
          s.getTracks().forEach((t) => t.stop());
          return;
        }
        camStreamRef.current = s;
        cam.srcObject = s;
        cam.play().catch(() => {});
      } catch {
        /* camera/mic blocked — call still records avatars */
      }

      const canvas = wrapRef.current?.querySelector('canvas');
      if (!canvas) return;
      canvas.width = 1280;
      canvas.height = 720;
      const ctx = canvas.getContext('2d');

      const draw = () => {
        paint(ctx);
        rafRef.current = requestAnimationFrame(draw);
      };
      draw();

      try {
        const cvStream = canvas.captureStream(30);
        if (camStreamRef.current) camStreamRef.current.getAudioTracks().forEach((t) => cvStream.addTrack(t));
        const mime =
          ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].find(
            (t) => typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(t),
          ) || '';
        const rec = new MediaRecorder(cvStream, mime ? { mimeType: mime } : undefined);
        chunksRef.current = [];
        rec.ondataavailable = (e) => e.data && e.data.size && chunksRef.current.push(e.data);
        rec.onstop = finalize;
        recorderRef.current = rec;
        rec.start(500);
      } catch {
        /* MediaRecorder unsupported */
      }

      timerRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    }

    begin();
    return () => {
      cancelled = true;
      clearInterval(timerRef.current);
      cancelAnimationFrame(rafRef.current);
      [camStreamRef.current, screenStreamRef.current].forEach((s) => s && s.getTracks().forEach((t) => t.stop()));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function paint(ctx) {
    if (!ctx) return;
    const W = 1280,
      H = 720;
    ctx.fillStyle = '#0d0d12';
    ctx.fillRect(0, 0, W, H);
    const t = timerRef.current ? Math.floor(performance.now() / 2000) : 0;
    const speak = t % 3;
    const { camOn: cOn, sharing: sh } = stateRef.current;
    const camV = camVideoRef.current;

    const cover = (video, x, y, w, h) => {
      const vw = video.videoWidth,
        vh = video.videoHeight;
      if (!vw || !vh) return false;
      const scale = Math.max(w / vw, h / vh);
      ctx.save();
      roundRect(ctx, x, y, w, h, 14);
      ctx.clip();
      ctx.drawImage(video, x + (w - vw * scale) / 2, y + (h - vh * scale) / 2, vw * scale, vh * scale);
      ctx.restore();
      return true;
    };
    const avatar = (x, y, w, h, name, color, on) => {
      ctx.fillStyle = '#16161d';
      roundRect(ctx, x, y, w, h, 14);
      ctx.fill();
      if (on) {
        ctx.strokeStyle = '#2ecc71';
        ctx.lineWidth = 3;
        roundRect(ctx, x + 1.5, y + 1.5, w - 3, h - 3, 13);
        ctx.stroke();
      }
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(x + w / 2, y + h / 2 - 6, Math.min(w, h) * 0.16, 0, 6.2832);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.font = `600 ${Math.round(Math.min(w, h) * 0.16)}px Inter, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(name[0], x + w / 2, y + h / 2 - 4);
    };
    const label = (x, y, h, name) => {
      ctx.textAlign = 'left';
      ctx.textBaseline = 'alphabetic';
      ctx.font = '500 15px Inter, sans-serif';
      const tw = ctx.measureText(name).width + 20;
      ctx.fillStyle = 'rgba(0,0,0,.55)';
      roundRect(ctx, x + 10, y + h - 32, tw, 22, 6);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.fillText(name, x + 20, y + h - 16);
    };

    if (sh && screenVideoRef.current.videoWidth) {
      cover(screenVideoRef.current, 24, 24, W - 48, H - 48);
      const pw = 260,
        ph = 150,
        px = W - pw - 40,
        py = H - ph - 40;
      if (cOn && camV.videoWidth) cover(camV, px, py, pw, ph);
      else avatar(px, py, pw, ph, 'You', '#e5352b', speak === 0);
      label(px, py, ph, 'You (sharing)');
    } else {
      const tiles = [{ name: 'You', color: '#e5352b', me: true }, ...TEAMMATES];
      const cols = 2,
        gap = 20,
        pad = 24;
      const tw = (W - pad * 2 - gap) / cols,
        th = (H - pad * 2 - gap) / 2;
      tiles.forEach((tile, i) => {
        const gx = pad + (i % cols) * (tw + gap),
          gy = pad + Math.floor(i / cols) * (th + gap);
        const on = (tile.me && speak === 0) || (tile.name === 'Sara' && speak === 1) || (tile.name === 'Omar' && speak === 2);
        if (tile.me && cOn && camV.videoWidth) {
          cover(camV, gx, gy, tw, th);
          if (on) {
            ctx.strokeStyle = '#2ecc71';
            ctx.lineWidth = 3;
            roundRect(ctx, gx + 1.5, gy + 1.5, tw - 3, th - 3, 13);
            ctx.stroke();
          }
        } else {
          avatar(gx, gy, tw, th, tile.name, tile.color, on);
        }
        label(gx, gy, th, tile.me ? 'You' : tile.name);
      });
    }
  }

  function toggleMic() {
    const next = !micOn;
    setMicOn(next);
    camStreamRef.current?.getAudioTracks().forEach((t) => (t.enabled = next));
  }
  function toggleCam() {
    const next = !camOn;
    setCamOn(next);
    camStreamRef.current?.getVideoTracks().forEach((t) => (t.enabled = next));
  }
  async function toggleShare() {
    if (sharing) {
      screenStreamRef.current?.getTracks().forEach((t) => t.stop());
      screenStreamRef.current = null;
      setSharing(false);
      return;
    }
    try {
      const s = await navigator.mediaDevices.getDisplayMedia({ video: true });
      screenStreamRef.current = s;
      screenVideoRef.current.srcObject = s;
      screenVideoRef.current.play().catch(() => {});
      setSharing(true);
      s.getVideoTracks()[0].addEventListener('ended', () => setSharing(false));
    } catch {
      /* denied */
    }
  }

  const endDurationRef = useRef(0);
  function endCall() {
    if (ending) return;
    setEnding(true);
    endDurationRef.current = elapsed;
    clearInterval(timerRef.current);
    cancelAnimationFrame(rafRef.current);
    if (recorderRef.current && recorderRef.current.state !== 'inactive') recorderRef.current.stop();
    else finalize();
  }

  async function finalize() {
    const blob = new Blob(chunksRef.current, { type: recorderRef.current?.mimeType || 'video/webm' });
    [camStreamRef.current, screenStreamRef.current].forEach((s) => s && s.getTracks().forEach((t) => t.stop()));
    const kind = aiOn ? 'meeting' : 'syncup';
    if (!blob.size) {
      router.push(`/?kind=${kind}`);
      return;
    }

    const now = new Date();
    const p = (n) => String(n).padStart(2, '0');
    const stamp = `${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())} ${p(now.getHours())}:${p(now.getMinutes())}`;

    const form = new FormData();
    form.append('video', blob, 'call.webm');
    form.append('kind', kind);
    form.append('duration', String(endDurationRef.current || elapsed));
    form.append('participants', JSON.stringify(['You', 'Sara', 'Omar']));
    form.append('transcript', JSON.stringify(TRANSCRIPT));
    if (aiOn) {
      form.append('title', `Meeting — ${stamp}`);
      form.append('summary', SUMMARY);
      form.append('actionItems', JSON.stringify(ACTIONS));
    } else {
      form.append('title', `SyncUp call — ${stamp}`);
    }

    setProgress(0);
    try {
      const slug = await upload('/api/clips', form, setProgress);
      router.push(`/clip/${slug}`);
    } catch {
      router.push(`/?kind=${kind}`);
    }
  }

  return (
    <div ref={wrapRef} className="fixed inset-0 z-[120] flex flex-col bg-rail">
      <div className="flex items-center gap-3 px-5 py-3">
        <span className="inline-flex items-center gap-2 rounded-full border border-brand/40 bg-brand/15 px-3 py-1.5 text-xs font-semibold text-brand">
          <span className="h-2.5 w-2.5 rounded-full bg-brand animate-pulseRec" /> REC · {formatDuration(elapsed)}
        </span>
        <span className="text-sm font-semibold">SyncUp call · You, Sara, Omar</span>
        <button
          onClick={() => setAiOn((v) => !v)}
          className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition ${
            aiOn ? 'border-purple-400/40 bg-purple-500/15 text-purple-300' : 'border-ink-700 text-muted'
          }`}
        >
          <SparkIcon width={14} height={14} /> AI Notetaker: {aiOn ? 'On' : 'Off'}
        </button>
        <span className="ml-auto hidden text-xs text-faint sm:inline">
          {aiOn ? 'Saves to AI Notetaker with transcript & summary' : 'Saves to SyncUps'} when the call ends
        </span>
      </div>

      <div className="grid flex-1 place-items-center px-5">
        <div className="relative aspect-video w-full max-w-4xl overflow-hidden rounded-2xl border border-ink-700 bg-ink-950">
          <canvas className="h-full w-full" />
          {progress >= 0 && (
            <div className="absolute inset-0 grid place-items-center bg-black/60">
              <div className="w-64 text-center">
                <div className="h-2 overflow-hidden rounded-full bg-ink-800">
                  <div className="h-full rounded-full bg-brand transition-all" style={{ width: `${progress}%` }} />
                </div>
                <p className="mt-2 text-sm text-white/80">Saving recording… {progress}%</p>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center justify-center gap-3 py-4">
        <CallButton onClick={toggleMic} off={!micOn} title="Mute">
          {micOn ? <MicIcon width={20} height={20} /> : <MuteIcon width={20} height={20} />}
        </CallButton>
        <CallButton onClick={toggleCam} off={!camOn} title="Camera">
          <VideoIcon width={20} height={20} />
        </CallButton>
        <CallButton onClick={toggleShare} off={sharing} title="Share screen">
          <ScreenIcon width={20} height={20} />
        </CallButton>
        <button
          onClick={endCall}
          disabled={ending}
          className="grid h-12 w-16 place-items-center rounded-full bg-brand text-white transition hover:bg-brand-hover disabled:opacity-60"
          title="End call"
        >
          <PhoneIcon width={22} height={22} />
        </button>
      </div>
      <p className="pb-4 text-center text-[11px] text-faint">
        Ending the call stops recording and files it under {aiOn ? 'AI Notetaker' : 'SyncUps'} automatically.
      </p>
    </div>
  );
}

function CallButton({ onClick, off, title, children }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`grid h-12 w-12 place-items-center rounded-full transition ${
        off ? 'bg-[#3a2326] text-brand' : 'bg-ink-850 text-white/90 hover:bg-ink-800'
      }`}
    >
      {children}
    </button>
  );
}

// XHR upload with progress.
function upload(url, formData, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          resolve(JSON.parse(xhr.responseText).slug);
        } catch {
          reject(new Error('bad response'));
        }
      } else reject(new Error('upload failed'));
    };
    xhr.onerror = () => reject(new Error('network error'));
    xhr.send(formData);
  });
}
