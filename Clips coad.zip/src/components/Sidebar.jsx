'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  GridIcon,
  VideoIcon,
  MicIcon,
  SyncIcon,
  SparkIcon,
  PlusIcon,
} from './icons';

const NAV = [
  { key: 'all', label: 'All Clips', href: '/', icon: GridIcon },
  { key: 'video', label: 'Video Clips', href: '/?kind=video', icon: VideoIcon, badgeKey: 'video' },
  { key: 'voice', label: 'Voice Clips', href: '/?kind=voice', icon: MicIcon },
  { key: 'syncup', label: 'SyncUps', href: '/?kind=syncup', icon: SyncIcon },
  { key: 'meeting', label: 'AI Notetaker', href: '/?kind=meeting', icon: SparkIcon },
];

export default function Sidebar({ counts = {}, activeKind }) {
  const pathname = usePathname();

  return (
    <aside className="hidden w-60 shrink-0 flex-col border-r border-ink-700 bg-ink-900 md:flex">
      <div className="flex items-center justify-between px-4 pb-2 pt-4">
        <span className="text-sm font-semibold tracking-wide text-white/90">Clips</span>
        <button
          onClick={() => window.dispatchEvent(new Event('clips:record'))}
          className="grid h-6 w-6 place-items-center rounded-md text-muted transition hover:bg-ink-800 hover:text-white"
          title="New clip"
        >
          <PlusIcon width={16} height={16} />
        </button>
      </div>

      <nav className="flex-1 space-y-0.5 px-2">
        {NAV.map((item) => {
          const Icon = item.icon;
          const isActive =
            pathname === '/' &&
            ((item.key === 'all' && !activeKind) || item.key === activeKind);
          const badge = item.badgeKey ? counts[item.badgeKey] : undefined;
          return (
            <Link
              key={item.key}
              href={item.href}
              className={`group flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm transition ${
                isActive
                  ? 'bg-ink-800 text-white'
                  : 'text-muted hover:bg-ink-850 hover:text-white/90'
              }`}
            >
              <Icon width={17} height={17} className="shrink-0 opacity-90" />
              <span className="flex-1 truncate">{item.label}</span>
              {item.soon && (
                <span className="rounded bg-ink-800 px-1.5 py-0.5 text-[9px] font-medium uppercase tracking-wide text-faint">
                  soon
                </span>
              )}
              {badge ? (
                <span className="min-w-[18px] rounded-full bg-ink-700 px-1.5 text-center text-[11px] font-medium text-white/70">
                  {badge}
                </span>
              ) : null}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
