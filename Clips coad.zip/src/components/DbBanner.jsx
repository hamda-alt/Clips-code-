export default function DbBanner() {
  return (
    <div className="animate-fadeIn rounded-2xl border border-amber-500/30 bg-amber-500/10 p-6 text-sm">
      <h2 className="text-base font-semibold text-amber-200">Can’t reach MySQL</h2>
      <p className="mt-1.5 max-w-2xl text-amber-100/80">
        The app is running but couldn’t connect to your database. Copy{' '}
        <code className="rounded bg-black/30 px-1">.env.example</code> to{' '}
        <code className="rounded bg-black/30 px-1">.env.local</code>, set your{' '}
        <code className="rounded bg-black/30 px-1">DB_*</code> values, then create the schema:
      </p>
      <pre className="mt-3 overflow-x-auto rounded-lg bg-black/40 p-3 text-[12px] text-amber-100/90">
        npm run db:setup   {'#'} or: mysql -u root -p &lt; db/schema.sql
      </pre>
    </div>
  );
}
