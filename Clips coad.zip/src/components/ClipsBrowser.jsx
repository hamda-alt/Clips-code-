'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import ClipCard from './ClipCard';
import ClipRow from './ClipRow';
import { ChevronDown, RecordIcon, GridIcon, SearchIcon, BackIcon } from './icons';

const LABELS = { video: 'Video Clips', voice: 'Voice Clips', syncup: 'SyncUps', meeting: 'AI Notetaker' };

// A list-view (bulleted rows) icon.
function ListIcon(props) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" {...props}>
      <path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01" />
    </svg>
  );
}

export default function ClipsBrowser({ clips, kind, heading, isSearch }) {
  const [layout, setLayout] = useState('gallery'); // 'gallery' | 'list'
  const [sortAsc, setSortAsc] = useState(false); // by created_at
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');

  const title = heading || LABELS[kind] || 'All Clips';

  // Filter within this section (title / summary / transcript) then sort by date.
  const sorted = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = q
      ? clips.filter(
          (c) =>
            (c.title || '').toLowerCase().includes(q) ||
            (c.summary || '').toLowerCase().includes(q) ||
            (Array.isArray(c.transcript) ? c.transcript : []).some((t) => (t.text || '').toLowerCase().includes(q)),
        )
      : clips;
    const by = (c) => new Date((c.created_at || '').replace(' ', 'T') + 'Z').getTime() || 0;
    const arr = [...filtered].sort((a, b) => by(a) - by(b));
    return sortAsc ? arr : arr.reverse();
  }, [clips, sortAsc, query]);

  return (
    <section className="animate-fadeIn">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-semibold tracking-tight">{title}</h1>
        <span className="text-[13px] text-faint">
          {clips.length} {isSearch ? 'result' : 'clip'}
          {clips.length === 1 ? '' : 's'}
        </span>
      </div>

      {/* Sort + view toggle */}
      <div className="mb-4 flex items-center justify-between">
        <button
          onClick={() => setSortAsc((v) => !v)}
          className="flex items-center gap-1.5 rounded-lg bg-indigo-500/15 px-2.5 py-1.5 text-[13px] font-medium text-indigo-300 transition hover:bg-indigo-500/25"
        >
          <ChevronDown
            width={14}
            height={14}
            className="transition"
            style={{ transform: sortAsc ? 'rotate(180deg)' : 'none' }}
          />
          Sort: Date created
        </button>
        <div className="flex items-center gap-2.5">
          {searchOpen ? (
            <div className="flex items-center gap-2 rounded-lg border border-ink-700 bg-ink-900 px-2.5 py-1.5 text-muted focus-within:border-ink-600">
              <SearchIcon width={15} height={15} />
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') {
                    setSearchOpen(false);
                    setQuery('');
                  }
                }}
                placeholder="Search…"
                className="w-44 min-w-0 bg-transparent text-sm text-white placeholder:text-faint outline-none"
              />
              <button
                onClick={() => {
                  setSearchOpen(false);
                  setQuery('');
                }}
                className="grid h-5 w-5 place-items-center rounded text-faint hover:bg-ink-800 hover:text-white"
                title="Close"
              >
                <BackIcon width={14} height={14} />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setSearchOpen(true)}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[13px] font-medium text-muted transition hover:bg-ink-850 hover:text-white"
            >
              <SearchIcon width={15} height={15} /> Search
            </button>
          )}
          <div className="flex gap-0.5 rounded-lg border border-ink-700 bg-ink-900 p-0.5">
            <button
              onClick={() => setLayout('list')}
              title="List view"
              className={`grid h-7 w-8 place-items-center rounded-md transition ${
                layout === 'list' ? 'bg-ink-800 text-white' : 'text-muted hover:text-white'
              }`}
            >
              <ListIcon />
            </button>
            <button
              onClick={() => setLayout('gallery')}
              title="Gallery view"
              className={`grid h-7 w-8 place-items-center rounded-md transition ${
                layout === 'gallery' ? 'bg-ink-800 text-white' : 'text-muted hover:text-white'
              }`}
            >
              <GridIcon width={16} height={16} />
            </button>
          </div>
        </div>
      </div>

      {sorted.length === 0 ? (
        <p className="py-16 text-sm text-faint">No matches. Try a different search.</p>
      ) : layout === 'list' ? (
        <div className="overflow-hidden rounded-xl border border-ink-700">
          <div className="grid grid-cols-[1fr_150px_140px_40px] gap-3 border-b border-ink-700 bg-ink-900 px-4 py-2.5 text-xs text-faint">
            <span>Name</span>
            <span
              className="flex cursor-pointer items-center gap-1"
              onClick={() => setSortAsc((v) => !v)}
            >
              Date created <ChevronDown width={13} height={13} />
            </span>
            <span>Created by</span>
            <span />
          </div>
          {sorted.map((clip) => (
            <ClipRow key={clip.slug} clip={clip} />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {sorted.map((clip) => (
            <ClipCard key={clip.slug} clip={clip} />
          ))}
          {!isSearch && kind !== 'meeting' && kind !== 'syncup' && (
            <Link
              href="/record"
              className="grid min-h-[180px] place-items-center rounded-xl border border-dashed border-ink-700 text-muted transition hover:border-brand hover:text-white"
            >
              <span className="flex flex-col items-center gap-2 text-sm">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-ink-850">
                  <RecordIcon width={18} height={18} className="text-brand" />
                </span>
                New Clip
              </span>
            </Link>
          )}
        </div>
      )}
    </section>
  );
}
