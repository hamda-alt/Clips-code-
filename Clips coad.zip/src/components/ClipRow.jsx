'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { DotsIcon, MicIcon, PencilIcon, DownloadIcon, TrashIcon } from './icons';
import { timeAgo } from '@/lib/format';

// One row of the list (table) view.
export default function ClipRow({ clip }) {
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    if (!menuOpen) return;
    const onClick = (e) => menuRef.current && !menuRef.current.contains(e.target) && setMenuOpen(false);
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, [menuOpen]);

  function open() {
    router.push(`/clip/${clip.slug}`);
  }

  async function rename(e) {
    e.stopPropagation();
    setMenuOpen(false);
    const next = window.prompt('Rename clip', clip.title);
    if (!next || !next.trim() || next === clip.title) return;
    setBusy(true);
    await fetch(`/api/clips/${clip.slug}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: next.trim() }),
    });
    setBusy(false);
    router.refresh();
  }

  async function remove(e) {
    e.stopPropagation();
    setMenuOpen(false);
    if (!window.confirm(`Delete “${clip.title}”?`)) return;
    setBusy(true);
    await fetch(`/api/clips/${clip.slug}`, { method: 'DELETE' });
    setBusy(false);
    router.refresh();
  }

  return (
    <div
      onClick={open}
      className={`grid cursor-pointer grid-cols-[1fr_150px_140px_40px] items-center gap-3 border-b border-ink-800 px-4 py-2.5 transition last:border-none hover:bg-ink-850 ${
        busy ? 'opacity-50' : ''
      }`}
    >
      <div className="flex min-w-0 items-center gap-3">
        <span className="relative h-8 w-12 shrink-0 overflow-hidden rounded bg-black">
          {clip.kind === 'voice' ? (
            <span className="grid h-full w-full place-items-center bg-gradient-to-br from-brand/25 to-purple-600/10 text-brand">
              <MicIcon width={14} height={14} />
            </span>
          ) : (
            <video src={`${clip.video_path}#t=0.1`} preload="metadata" muted className="h-full w-full object-cover" />
          )}
        </span>
        <span className="truncate text-sm font-medium text-white/90">{clip.title}</span>
      </div>
      <span className="truncate text-[13px] text-muted">{timeAgo(clip.created_at)}</span>
      <span className="flex items-center gap-2">
        <span className="grid h-5 w-5 place-items-center rounded-full bg-gradient-to-br from-brand to-orange-500 text-[9px] font-bold text-white">
          {(clip.author_name || 'Y').charAt(0).toUpperCase()}
        </span>
        <span className="truncate text-[13px] text-muted">{clip.author_name || 'You'}</span>
      </span>
      <div className="relative flex justify-end" ref={menuRef}>
        <button
          onClick={(e) => {
            e.stopPropagation();
            setMenuOpen((v) => !v);
          }}
          className="grid h-7 w-7 place-items-center rounded-md text-muted transition hover:bg-ink-800 hover:text-white"
          aria-label="Options"
        >
          <DotsIcon width={16} height={16} />
        </button>
        {menuOpen && (
          <div className="absolute right-0 top-8 z-20 w-40 animate-fadeIn overflow-hidden rounded-lg border border-ink-700 bg-ink-900 py-1 shadow-pop">
            <button onClick={rename} className="flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm text-white/80 hover:bg-ink-800">
              <PencilIcon width={15} height={15} className="text-muted" /> Rename
            </button>
            <a
              href={clip.video_path}
              download={`${clip.title}.${clip.video_path.split('.').pop()}`}
              onClick={(e) => e.stopPropagation()}
              className="flex items-center gap-2.5 px-3 py-2 text-sm text-white/80 hover:bg-ink-800"
            >
              <DownloadIcon width={15} height={15} className="text-muted" /> Download
            </a>
            <div className="my-1 h-px bg-ink-700" />
            <button onClick={remove} className="flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm text-brand hover:bg-ink-800">
              <TrashIcon width={15} height={15} /> Delete
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
