'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  RecordIcon,
  MicIcon,
  ChevronDown,
  CheckIcon,
  BackIcon,
  PlayIcon,
} from './icons';
import { formatDuration } from '@/lib/format';

const RESOLUTIONS = [
  { id: '720p', label: '720p', tag: 'HD', height: 720 },
  { id: '1080p', label: '1080p', tag: 'Full HD', height: 1080 },
  { id: '1440p', label: '1440p', tag: '2K', height: 1440, locked: true },
  { id: '2160p', label: '2160p', tag: '4K', height: 2160, locked: true },
  { id: 'native', label: 'Native', tag: 'Auto', height: 0 },
];

// idle → recording → preview → uploading
export default function Recorder({ initialKind = 'video' }) {
  const router = useRouter();
  const [phase, setPhase] = useState('idle');
  const [mode, setMode] = useState(initialKind === 'voice' ? 'voice' : 'screen');
  const [resolution, setResolution] = useState('1080p');
  const [micOn, setMicOn] = useState(true);

  // What the saved clip is filed as: a voice recording is always 'voice';
  // a screen recording keeps the section it was started from (video or syncup).
  const uploadKind = mode === 'voice' ? 'voice' : initialKind === 'syncup' ? 'syncup' : 'video';
  const isVoice = mode === 'voice';
  const [elapsed, setElapsed] = useState(0);
  const [error, setError] = useState('');
  const [previewUrl, setPreviewUrl] = useState('');
  const [title, setTitle] = useState('');
  const [progress, setProgress] = useState(0);

  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const streamRef = useRef(null);
  const micStreamRef = useRef(null);
  const timerRef = useRef(null);
  const blobRef = useRef(null);
  const durationRef = useRef(0);

  const cleanupStreams = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    micStreamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    micStreamRef.current = null;
  }, []);

  useEffect(() => {
    return () => {
      clearInterval(timerRef.current);
      cleanupStreams();
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [cleanupStreams, previewUrl]);

  async function startVoiceRecording() {
    setError('');
    if (!navigator.mediaDevices?.getUserMedia) {
      setError('Microphone recording isn’t supported in this browser. Try Chrome or Edge.');
      return;
    }
    try {
      const mic = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = mic;
      const mimeType = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg'].find(
        (t) => typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(t),
      ) || '';
      const recorder = new MediaRecorder(mic, mimeType ? { mimeType } : undefined);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.onstop = handleStop;
      mediaRecorderRef.current = recorder;
      recorder.start(250);
      setPhase('recording');
      setElapsed(0);
      timerRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    } catch (err) {
      setError(err?.name === 'NotAllowedError' ? 'Microphone access was blocked.' : 'Couldn’t start: ' + (err?.message || 'unknown error'));
      cleanupStreams();
    }
  }

  async function startRecording() {
    if (mode === 'voice') return startVoiceRecording();
    setError('');
    if (!navigator.mediaDevices?.getDisplayMedia) {
      setError('Screen recording isn’t supported in this browser. Try Chrome or Edge.');
      return;
    }

    const chosen = RESOLUTIONS.find((r) => r.id === resolution);
    if (chosen?.locked) {
      setError('That resolution needs the Business plan. Recording at 1080p instead.');
    }
    const height = chosen?.locked ? 1080 : chosen?.height || undefined;

    try {
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: height ? { height: { ideal: height }, frameRate: { ideal: 30 } } : true,
        audio: true, // system audio when the user shares a tab/screen with audio
      });
      streamRef.current = displayStream;

      // Merge microphone audio if requested.
      let tracks = [...displayStream.getTracks()];
      if (micOn) {
        try {
          const mic = await navigator.mediaDevices.getUserMedia({ audio: true });
          micStreamRef.current = mic;
          tracks = [...displayStream.getVideoTracks(), ...displayStream.getAudioTracks(), ...mic.getAudioTracks()];
        } catch {
          // Mic denied — keep recording screen only.
        }
      }
      const combined = new MediaStream(tracks);

      const mimeType = pickMimeType();
      const recorder = new MediaRecorder(combined, mimeType ? { mimeType } : undefined);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.onstop = handleStop;
      mediaRecorderRef.current = recorder;

      // Stop automatically if the user ends sharing via the browser bar.
      displayStream.getVideoTracks()[0].addEventListener('ended', () => {
        if (mediaRecorderRef.current?.state === 'recording') mediaRecorderRef.current.stop();
      });

      recorder.start(250);
      setPhase('recording');
      setElapsed(0);
      timerRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    } catch (err) {
      if (err?.name === 'NotAllowedError') {
        setError('Screen share was cancelled.');
      } else {
        setError('Couldn’t start recording: ' + (err?.message || 'unknown error'));
      }
      cleanupStreams();
    }
  }

  function stopRecording() {
    clearInterval(timerRef.current);
    durationRef.current = elapsed;
    if (mediaRecorderRef.current?.state !== 'inactive') {
      mediaRecorderRef.current?.stop();
    }
  }

  function handleStop() {
    cleanupStreams();
    const type = mediaRecorderRef.current?.mimeType || 'video/webm';
    const blob = new Blob(chunksRef.current, { type });
    blobRef.current = blob;
    const url = URL.createObjectURL(blob);
    setPreviewUrl(url);
    setTitle(defaultTitle(uploadKind));
    setPhase('preview');
  }

  async function upload() {
    if (!blobRef.current) return;
    setPhase('uploading');
    setProgress(0);

    const form = new FormData();
    const ext = blobRef.current.type.includes('mp4') ? 'mp4' : blobRef.current.type.includes('audio') ? 'weba' : 'webm';
    form.append('video', blobRef.current, `clip.${ext}`);
    form.append('title', title.trim() || defaultTitle(uploadKind));
    form.append('duration', String(durationRef.current || elapsed));
    form.append('resolution', resolution);
    form.append('kind', uploadKind);

    try {
      const slug = await uploadWithProgress('/api/clips', form, setProgress);
      router.push(`/clip/${slug}`);
    } catch (err) {
      setError(err.message || 'Upload failed.');
      setPhase('preview');
    }
  }

  function discard() {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl('');
    blobRef.current = null;
    setPhase('idle');
    setElapsed(0);
    setError('');
  }

  /* -------------------------------- render -------------------------------- */

  if (phase === 'recording') {
    return (
      <div className="grid min-h-[70vh] place-items-center">
        <div className="flex flex-col items-center gap-6 text-center">
          <div className="flex items-center gap-3 rounded-full border border-ink-700 bg-ink-900 px-5 py-2.5">
            <span className="h-3 w-3 rounded-full bg-brand animate-pulseRec" />
            <span className="text-lg font-semibold tabular-nums">{formatDuration(elapsed)}</span>
            <span className="text-sm text-muted">Recording…</span>
          </div>
          <button
            onClick={stopRecording}
            className="flex items-center gap-2 rounded-lg bg-brand px-6 py-3 text-sm font-semibold text-white transition hover:bg-brand-hover"
          >
            <span className="h-3 w-3 rounded-[3px] bg-white" />
            Stop recording
          </button>
          <p className="text-xs text-faint">
            {isVoice ? 'Speak your update, then tap Stop.' : 'Or end the share from your browser’s toolbar.'}
          </p>
        </div>
      </div>
    );
  }

  if (phase === 'preview' || phase === 'uploading') {
    const uploading = phase === 'uploading';
    return (
      <div className="mx-auto max-w-3xl animate-fadeIn">
        <h1 className="mb-4 text-xl font-semibold">Review your {isVoice ? 'voice clip' : 'clip'}</h1>
        {isVoice ? (
          <div className="flex flex-col items-center gap-4 rounded-2xl border border-ink-700 bg-gradient-to-br from-brand/15 to-purple-600/10 px-6 py-8">
            <MicIcon width={40} height={40} className="text-brand" />
            <audio src={previewUrl} controls className="w-full" />
          </div>
        ) : (
          <div className="overflow-hidden rounded-2xl border border-ink-700 bg-black">
            <video src={previewUrl} controls playsInline className="aspect-video w-full" />
          </div>
        )}

        <label className="mt-5 block text-xs font-medium text-muted">Title</label>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          disabled={uploading}
          className="mt-1.5 w-full rounded-lg border border-ink-700 bg-ink-900 px-3 py-2.5 text-sm text-white outline-none transition focus:border-brand"
        />

        {error && <p className="mt-3 text-sm text-brand">{error}</p>}

        {uploading ? (
          <div className="mt-6">
            <div className="h-2 overflow-hidden rounded-full bg-ink-800">
              <div
                className="h-full rounded-full bg-brand transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="mt-2 text-center text-sm text-muted">Uploading… {progress}%</p>
          </div>
        ) : (
          <div className="mt-6 flex items-center gap-3">
            <button
              onClick={upload}
              className="flex-1 rounded-lg bg-brand px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-hover"
            >
              Save &amp; get link
            </button>
            <button
              onClick={discard}
              className="rounded-lg border border-ink-700 px-5 py-3 text-sm font-medium text-muted transition hover:bg-ink-850 hover:text-white"
            >
              Discard
            </button>
          </div>
        )}
      </div>
    );
  }

  // idle
  return (
    <div className="mx-auto max-w-lg animate-fadeIn">
      <Link href="/" className="mb-6 inline-flex items-center gap-1.5 text-sm text-muted hover:text-white">
        <BackIcon width={16} height={16} /> Back to Clips
      </Link>

      <div className="rounded-2xl border border-ink-700 bg-ink-850 p-6">
        <div className="mb-1 flex items-center gap-2">
          <RecordIcon width={20} height={20} className="text-brand" />
          <h1 className="text-lg font-semibold">
            Record a {initialKind === 'syncup' ? 'SyncUp' : isVoice ? 'voice clip' : 'clip'}
          </h1>
        </div>
        <p className="mb-6 text-sm text-muted">
          {isVoice
            ? 'Record a quick audio note and share it with a link the moment you stop.'
            : initialKind === 'syncup'
              ? 'Record your SyncUp call to give teammates context — a link is ready the moment you stop.'
              : 'Pick a quality, choose what to share, and we’ll give you a link the moment you stop.'}
        </p>

        {/* Screen / Voice mode — hidden for SyncUps (always a screen call) */}
        {initialKind !== 'syncup' && (
          <div className="mb-5 flex gap-1.5 rounded-xl border border-ink-700 bg-ink-900 p-1">
            {[
              { id: 'screen', label: 'Screen', icon: RecordIcon },
              { id: 'voice', label: 'Voice', icon: MicIcon },
            ].map((m) => {
              const Icon = m.icon;
              const active = mode === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => setMode(m.id)}
                  className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-sm font-medium transition ${
                    active ? 'bg-ink-800 text-white' : 'text-muted hover:text-white'
                  }`}
                >
                  <Icon width={16} height={16} /> {m.label}
                </button>
              );
            })}
          </div>
        )}

        {!isVoice && (
          <>
            <label className="mb-1.5 block text-xs font-medium text-muted">Resolution</label>
            <ResolutionPicker value={resolution} onChange={setResolution} />
          </>
        )}

        <button
          onClick={() => setMicOn((v) => !v)}
          className="mt-4 flex w-full items-center gap-3 rounded-lg border border-ink-700 bg-ink-900 px-3 py-2.5 text-sm transition hover:border-ink-600"
        >
          <MicIcon width={18} height={18} className={micOn || isVoice ? 'text-white' : 'text-faint'} />
          <span className="flex-1 text-left text-white/90">Microphone</span>
          {isVoice ? (
            <span className="text-xs text-emerald-400">Always on</span>
          ) : (
            <span className={`relative h-5 w-9 rounded-full transition ${micOn ? 'bg-brand' : 'bg-ink-700'}`}>
              <span
                className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${
                  micOn ? 'left-4' : 'left-0.5'
                }`}
              />
            </span>
          )}
        </button>

        {error && <p className="mt-4 text-sm text-brand">{error}</p>}

        <button
          onClick={startRecording}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-brand px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-hover"
        >
          <span className="h-2.5 w-2.5 rounded-full bg-white" />
          Start recording
        </button>
        <p className="mt-3 text-center text-xs text-faint">
          {isVoice
            ? 'Your browser will ask to use your microphone.'
            : 'Your browser will ask which screen, window, or tab to capture.'}
        </p>
      </div>
    </div>
  );
}

/* ---- resolution dropdown ------------------------------------------------- */

function ResolutionPicker({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const current = RESOLUTIONS.find((r) => r.id === value);

  useEffect(() => {
    const onClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-2 rounded-lg border border-ink-700 bg-ink-900 px-3 py-2.5 text-sm transition hover:border-ink-600"
      >
        <span className="font-medium text-white">{current?.label}</span>
        <span className="rounded bg-ink-800 px-1.5 py-0.5 text-[10px] text-muted">{current?.tag}</span>
        <span className="flex-1" />
        <ChevronDown width={16} height={16} className="text-faint" />
      </button>

      {open && (
        <div className="absolute z-20 mt-1.5 w-full animate-fadeIn overflow-hidden rounded-lg border border-ink-700 bg-ink-900 py-1 shadow-pop">
          {RESOLUTIONS.map((r) => (
            <button
              key={r.id}
              onClick={() => {
                onChange(r.id);
                setOpen(false);
              }}
              className="flex w-full items-center gap-2 px-3 py-2 text-sm transition hover:bg-ink-800"
            >
              <span className="w-4">
                {value === r.id && <CheckIcon width={14} height={14} className="text-brand" />}
              </span>
              <span className="font-medium text-white/90">{r.label}</span>
              <span className="rounded bg-ink-800 px-1.5 py-0.5 text-[10px] text-muted">{r.tag}</span>
              <span className="flex-1" />
              {r.locked && (
                <span className="rounded bg-brand/15 px-2 py-0.5 text-[10px] font-medium text-brand">
                  Upgrade
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---- helpers ------------------------------------------------------------- */

function pickMimeType() {
  const candidates = [
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm',
    'video/mp4',
  ];
  if (typeof MediaRecorder === 'undefined') return '';
  return candidates.find((t) => MediaRecorder.isTypeSupported(t)) || '';
}

function defaultTitle(kind = 'video') {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  const prefix = kind === 'voice' ? 'voice-note' : kind === 'syncup' ? 'syncup' : 'screen-recording';
  return `${prefix}-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}-${p(
    d.getMinutes(),
  )}`;
}

// XHR gives us real upload progress (fetch can't stream it in browsers yet).
function uploadWithProgress(url, formData, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          resolve(JSON.parse(xhr.responseText).slug);
        } catch {
          reject(new Error('Bad server response.'));
        }
      } else {
        let msg = 'Upload failed.';
        try {
          msg = JSON.parse(xhr.responseText).error || msg;
        } catch {
          /* ignore */
        }
        reject(new Error(msg));
      }
    };
    xhr.onerror = () => reject(new Error('Network error during upload.'));
    xhr.send(formData);
  });
}
