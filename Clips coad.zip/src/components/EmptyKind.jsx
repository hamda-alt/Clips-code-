import Link from 'next/link';
import { VideoIcon, MicIcon, SyncIcon, SparkIcon, RecordIcon } from './icons';

const CONFIG = {
  video: {
    label: 'Video Clips',
    icon: VideoIcon,
    blurb: 'Record your screen to give your teammates context. Every screen recording you make shows up here.',
    cta: 'Record a video clip',
    href: '/record?kind=video',
  },
  voice: {
    label: 'Voice Clips',
    icon: MicIcon,
    blurb: 'Record a quick audio note to give your teammates context. Every voice clip you make shows up here.',
    cta: 'Record a voice clip',
    href: '/record?kind=voice',
  },
  syncup: {
    label: 'SyncUps',
    icon: SyncIcon,
    blurb:
      'Start a SyncUp call from a chat with your teammates. It records automatically and saves right here the moment the call ends.',
    cta: null, // calls start from a chat/DM, not from this page
    href: null,
  },
  meeting: {
    label: 'AI Notetaker',
    icon: SparkIcon,
    blurb:
      'Once AI Notetaker joins a meeting and records it, the recording — with an AI transcript, summary and action items — is available here after the call ends.',
    cta: null, // needs a server-side meeting bot; nothing for the user to click
    href: null,
  },
};

export default function EmptyKind({ kind }) {
  const c = CONFIG[kind] || CONFIG.video;
  const Icon = c.icon;
  return (
    <section className="animate-fadeIn">
      <h1 className="mb-8 text-xl font-semibold tracking-tight">{c.label}</h1>
      <div className="grid place-items-center py-20 text-center">
        <span className="mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-ink-850 text-muted">
          <Icon width={26} height={26} />
        </span>
        <h2 className="text-base font-semibold">Your {c.label} will appear here</h2>
        <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-muted">{c.blurb}</p>
        {c.cta && (
          <Link
            href={c.href}
            className="mt-5 inline-flex items-center gap-2 rounded-lg bg-white px-5 py-2.5 text-sm font-semibold text-ink-950 transition hover:bg-white/90"
          >
            <RecordIcon width={16} height={16} className="text-brand" />
            {c.cta}
          </Link>
        )}
        {kind === 'meeting' && (
          <p className="mt-4 text-xs text-faint">
            In the full product, the bot joins your Zoom / Meet / Teams call and posts the recording here.
          </p>
        )}
      </div>
    </section>
  );
}
