// Executes db/schema.sql against the configured MySQL server.
// Usage: npm run db:setup   (reads DB_* from your environment / .env)
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import mysql from 'mysql2/promise';

const __dirname = dirname(fileURLToPath(import.meta.url));

async function main() {
  const schemaPath = join(__dirname, '..', 'db', 'schema.sql');
  const sql = await readFile(schemaPath, 'utf8');

  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true,
  });

  console.log('Applying db/schema.sql ...');
  await conn.query(sql);
  await conn.end();
  console.log('Done. Database "clips" is ready.');
}

main().catch((err) => {
  console.error('DB setup failed:', err.message);
  process.exit(1);
});
